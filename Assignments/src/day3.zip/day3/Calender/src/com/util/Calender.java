package com.util;

public class Calender {
    public MyDate date;

    public Calender(int day, int month, int year) {
        date = new MyDate(day, month, year);
    }
}
